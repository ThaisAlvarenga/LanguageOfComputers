'''
NAME: Thais Alvarenga
DATE: 30/01/2023

Prints the lyrics to my favorite song, Land of The Free by The Killers

'''
# adding a space so the print looks cleaner
print()

# printing the first verse
print("Can't wipe the wind-blown smile")
print("from across my face")
print("It's just the old man in me")
print("Washing his truck at the Sinclair station")
print("In the land of the free")
print("\t(Ooh)")
print("His mother, Adeline's family, came on a ship")
print("Cut coal and planted a seed")
print("Down in them drift mines of Pennsylvania")
print("In the land of the free")

# printing chorus with backslash to practice
print("\nLand of the free, land of the free \nIn the land of the free \nLand of the free, land of the free")
print("\nLand of the free, land of the free \nIn the land of the free \n\t (I'm standing crying)")

# space representing that I skipped a part of the song
print("\n(...)")

# print bridge
print("\n\t Oh-oh-oh-oh, oh-oh-oh-oh \n\t I'm standing, crying /n(Oh-oh-oh-oh) \n\t I'm standing, crying")

# print final verse
print("\nSo how many daughters,")
print('tell me, how many sons')
print("Do we have to have to put in the ground")
print("Before we just break down and face it:")
print("We got a problem with guns?")
print("\n\t(Oh-oh-oh-oh)")
print("\nIn the land of the free")
print("Down at the border, they're gonna put up a wall")
print("Concrete and Rebar Steel beams")
print("(I'm standing, crying)")
print("High enough to keep all those filthy hands off")
print("Of our hopes and our dreams (I'm standing, crying")
print("People who just want the same things we do")
print("In the land of the free")
