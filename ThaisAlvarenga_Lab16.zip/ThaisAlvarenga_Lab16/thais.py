#!/usr/bin/python3


print("Content-Type: text/html \n\n")

print()

print('''<!DOCTYPE html>

<html>

<head>
<title>Python Program</title>
<link rel="stylesheet" type="text/css" href="main.css">
</head>

<body>

<style>
body{
background-color: #FFF2CC;
}
</style>

''')

print("<h1> Hello </h1>")

num1 = 1
num2 = 4

print("<p> Sum of num1 and num2 is:", num1 + num2 , "</p>")

print("</body> </html>")
